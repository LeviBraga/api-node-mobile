const { Sequelize, DataTypes, STRING } = require('sequelize');
const sequelize = require('../config/database');
const { type } = require('express/lib/response');

const User = sequelize.define('Users', {
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false
    },
    username: {
        type: DataTypes.STRING,
        allowNull: false
    }
})

module.exports = User;